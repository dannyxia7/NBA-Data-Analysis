#' @title Counting Vowels
#' @description computes the number of vowels of a character string
#' @param str string, input where vowels will be counted
#' @return numeric, vector with count and names for vowels

count_vowels = function(str) {
  if (is.character(str) == FALSE) {
    stop("invalid input; a string was expected")
  }
  vowels = c("a", "e", "i", "o", "u")
  str = tolower(str)
  vec = table(factor(unlist(strsplit(str, ""), use.names = FALSE), levels = vowels))
  vec = as.numeric(vec)
  names(vec) = c("a", "e", "i", "o", "u")
  return(vec)
}