#' @title Reverse Characters
#' @description reverses a string by characters
#' @param str string, input to be reversed
#' @return string, reversed string

reverse_chars = function(str) {
  n = nchar(str)
  str = strsplit(str, NULL)[[1]]
  rev_str = rev(str)
  rev_str = paste(rev_str, collapse ="")
  return(rev_str)
}