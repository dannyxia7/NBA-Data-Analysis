#' @title Hex Color
#' @description Checks whether an input string is a valid hex color without an alpha transparency value
#' @param color string, hex color
#' @return boolean, whether hex color is valid or not

is_hex = function(color) {
  if(is.character(color) == TRUE) {
    colors = colors()
    for(i in 1:length(colors)) {
      if(color == colors[i]) {
        return(FALSE)
      }
    }
    col = try(col2rgb(color), silent = TRUE)
    return(!"try-error" %in% class(col))  
  }
  else {
    stop("invalid input; a string was expected")
  }
}


#' @title Hex and Alpha
#' @description checks whether an input string is a valid hex color with an alpha transparency value
#' @param color string, hex color with alpha transparency value
#' @return boolean, whether input is valid hex color with alpha value or not

is_hex_alpha = function(color) {
  if(is.character(color) == TRUE) {
    colors = colors()
    for(i in 1:length(colors)) {
      if(color == colors[i]) {
        return(FALSE)
      }
    }
    col = try(col2rgb(color, alpha = TRUE), silent = TRUE)
    if (col[4] < 255) {
      return(!"try-error" %in% class(col))
    }
    else {
      return(FALSE)
    }
  }
  else {
    stop("invalid input; a string was expected")
  }
}