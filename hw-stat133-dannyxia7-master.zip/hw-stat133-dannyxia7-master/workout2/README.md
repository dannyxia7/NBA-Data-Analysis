Workout 2 - Testing Functions and Strings

We have multiple functions here: computing Minkowski Distance, checking if a
string is in hexadecimal notation, reversing the characters of a string, and 
counting the number of vowels in a string.

In addition, we will implement tests for these functions using the R package
"testthat".

