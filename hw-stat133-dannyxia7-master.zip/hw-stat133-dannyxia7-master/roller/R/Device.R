#' @title Device Function
#' @description constructs device objects
#' @param sides possible outcomes
#' @param prob probability for each outcome (numeric)
#' @return device object
#' @export
#' @examples
#' #default
#' device = device()
#'

device = function(sides = c(1, 2), prob = c(0.5, 0.5)) {
  if(length(sides) != length(prob)) {
    stop("arguments sides and prob must be of the same length")
  }
  check_sides(sides)
  check_prob(prob)
  res = list(sides = sides, prob = prob)
  class(res) = "device"
  return(res)
}

#' @title Check Sides Function
#' @description checks if the length of the sides are valid
#' @param sides sides
#' @return logical, whether sides is valid or not
#'

check_sides = function(sides) {
  if (length(unique(sides)) < length(sides)) {
    stop("\n'sides' cannot contain duplicated elements")
  }
  if (length(sides) < 2) {
    stop("\n'sides' must have length longer than 1")
  }
  return(TRUE)
}

#' @title Probability Checking Function
#' @description checks if probability input is valid
#' @param prob probability (numeric)
#' @return logical, whether prob is valid or not

check_prob = function(prob) {
  if(length(prob) < 2 | !is.numeric(prob)) {
    stop("\n'prob' must be a numeric vector with length greater than 1")
  }
  if(any(prob > 1) | any(prob < 0)) {
    stop("\n'prob' values must be between zero and one")
  }
  if(sum(prob) != 1) {
    stop("\nelements in 'prob' must add up to 1")
  }
  return(TRUE)
}

#' @title Print Device
#' @description prints device objects
#' @param x device object
#' @return side and prob of device object

print.device = function(x) {
  cat('object "device"\n\n')
  freqs = data.frame(
    side = x$sides,
    prob = x$prob
  )
  print(freqs)
  invisible(x)
}

#' @title Device Checking Function
#' @description checks if object is a device object
#' @param x device object
#' @return logical, if device object is valid or not

is.device = function(x) {
  inherits(x, "device")
}

