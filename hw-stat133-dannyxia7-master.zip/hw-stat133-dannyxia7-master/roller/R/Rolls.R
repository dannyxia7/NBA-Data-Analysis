#' @title Generic Roll
#' @description generic function for roll
#' @param x object
#' @return depends on object
#' @export
roll = function(x, ...) UseMethod("roll")

#' @title Roll Function
#' @description simulates rolls for a device object
#' @param device device object
#' @param times number of times the object is rolled
#' @return rolls of device object
#' @export
#' @examples
#' #default
#' device = device()
#' device_roll = roll(device)
#'

roll.device = function(device, times = 1) {
  if(class(device) != "device") {
    stop("\nroll() requires an object 'device'")
  }
  check_times(times)
  rolls = sample(device$sides, size = times, replace = TRUE, prob = device$prob)
  make_rolls(device, rolls)
}

#' @title Make Rolls
#' @description creates list for return of rolls function
#' @param device device object
#' @param rolls simulated rolls
#' @return list of rolls, class rolls

make_rolls = function(device, rolls) {
  res = list(
    rolls = rolls,
    sides = device$sides,
    prob = device$prob,
    total = length(rolls)
  )
  class(res) = "rolls"
  res
}

#' @title Times Checking Function
#' @description auxillary checking function, if times is valid
#' @param times number of times device object is rolled
#' @return logical

check_times = function(times) {
  if (times < 1 | times%%1 != 0) {
    stop("\ntimes must be a positive integer greater than or equal to 1")
  }
  return(TRUE)
}

#' @title Rolls Print Function
#' @description prints the simulated rolls of the device object
#' @param x rolls object
#' @return simulated rolls

print.rolls = function(x) {
  cat('object "rolls"\n\n')
  cat("$rolls\n")
  cat(x$rolls)
  invisible(x)
}

#' @title Rolls Summary Function
#' @description provides summary of rolls object
#' @param x rolls object
#' @return summary of rolls

summary.rolls = function(x) {
  n = length(x$sides)
  proportions = rep(0, n)
  counts = rep(0, n)
  for(i in 1:n) {
    proportions[i] = sum(x$rolls == x$sides[i]) / x$total
    counts[i] = sum(x$rolls == x$sides[i])
  }
  freqs = data.frame(
    side = x$sides,
    count = counts,
    prop = proportions
  )
  obj = list(freqs = freqs)
  class(obj) = "summary.rolls"
  return(obj)
}

#' @title Print Summary Rolls
#' @description prints summary.rolls object
#' @param x rolls object
#' @return printed rolls information

print.summary.rolls = function(x, ...) {
  cat('summary "roll"\n\n')
  print(x$freqs)
  invisible(x)
}

#' @title Plot Rolls
#' @description creates plot for rolls object
#' @param rolls rolls object
#' @param total total number of coin tosses
#' @return plot of rolls frequencies

plot.rolls = function(x, total = 1, ...) {
  library(ggplot2)
  total = x$total
  freqs = frequencies(x)
  df = data.frame(x = as.character(x$sides), y = freqs)
  p = ggplot(df) +
    ggtitle(sprintf("Relative Frequencies in a series of %s coin tosses", total)) +
    xlab("sides of device") +
    ylab("relative frequencies") +
    geom_bar(stat = "identity", aes(x = x, y = y)) +
    theme_minimal()
  print(p)
}

#' @title Frequencies
#' @description creates frequencies of sides for plot
#' @param x rolls object
#' @return vector of proportions
#'
frequencies = function(x) {
  n = length(x$sides)
  proportions = rep(0, n)
  for(i in 1:n) {
    proportions[i] = sum(x$rolls == x$sides[i]) / x$total
  }
  return(proportions)
}

#' @title Extraction Method
#' @description extract value from rolls object
#' @param x rolls object
#' @param i index of value
#' @return value of desired roll from rolls object

"[.rolls" = function(x, i) {
  x$rolls[i]
}

#' @title Replacement Method
#' @description replace a side in rolls object
#' @param x rolls object
#' @param i index of value
#' @param value value that will replace a side
#' @return rolls object with replacement value

"[<-.rolls" = function(x, i, value) {
  if (any((x$sides %in% value)) == FALSE) {
    stop(sprintf('\nreplacing value must be one of the sides'))
  }
  if (i > x$total) {
    stop("\nindex out of bounds")
  }
  x$rolls[i] = value
  make_rolls(device(x$sides, x$prob), x$rolls)
}

#' @title Addition Method
#' @description add more rolls
#' @param x rolls object
#' @param add how many rolls added
#' @return rolls object with additional rolls

"+.rolls" = function(x, add) {
  if(length(add) != 1 | add <= 0) {
    stop("\nincrement must be positive")
  }
  more_rolls = roll(device(x$sides, x$prob), times = add)
  make_rolls(x, c(x$rolls, more_rolls$rolls))
}




