Roller Package - Workout 3

This package has functions that create a device object and simulate rolls for that device, and summaries and visualizations of it. This packageXX also uses auxillary checking functions hidden from the user.

In addition, we will implement tests for these functions using the R package "testthat"

