library(roller)

context("Test for Rolls object")

test_that("rolls function works as expected", {
  fair_die = device(c(1,2,3,4,5,6), rep(1/6, 6))
  set.seed(123)
  fair50 = roll(fair_die, 50)
  set.seed(123)
  fair50_2 = roll(fair_die, 50)

  expect_identical(fair50, fair50_2)
  expect_type(fair50, "list")
  expect_is(fair50, "rolls")
  expect_length(fair50, 4)
})

test_that("make_rolls works as expected", {
  x = device(c('a', 'b', 'c', 'd'), c(1/6, 1/3, 1/6, 1/3))
  rolls = sample(x$sides, size = 10, replace = TRUE, prob = x$prob)
  expect_is(make_rolls(x, rolls), "rolls")
  expect_length(make_rolls(x, rolls), 4)
  expect_type(make_rolls(x, rolls), "list")
})

test_that("check_times works as expected", {
  times_1 = -10
  times_2 = .5
  times_t = 1000
  expect_error(check_times(times_1))
  expect_error(check_times(times_2))
  expect_true(check_times(times_t))
})

test_that("print.rolls works as expected", {
  a = device(c('a', 'b', 'c', 'd'), c(1/6, 1/3, 1/6, 1/3))
  x = roll(a, times = 50)
  expect_length(x, 4)
  expect_type(x, 'list')
  expect_is(x, "rolls")
})

test_that("summary.rolls works as expected", {
  a = device(c('a', 'b', 'c', 'd'), c(1/6, 1/3, 1/6, 1/3))
  x = summary(roll(a, times = 50))
  expect_type(x, 'list')
  expect_is(x, "summary.rolls")
})

test_that("summary.print.rolls works as expected", {
  a = device(c('a', 'b', 'c', 'd'), c(1/6, 1/3, 1/6, 1/3))
  x = summary(roll(a, times = 50))
  expect_type(x, 'list')
  expect_is(x, "summary.rolls")
})

test_that("plot.rolls works as expected", {
  library(ggplot2)
  a = device(c('a', 'b', 'c', 'd'), c(1/6, 1/3, 1/6, 1/3))
  x = roll(a, times = 50)
  p = plot(x)
  expect_true(is.ggplot(p))
  expect_identical(p$labels$x, "sides of device")
  expect_identical(p$labels$y, "relative frequencies")
  expect_error(print(p), NA)
})

test_that("Frequencies works as expected", {
  a = device(c(1,2,3,4,5,6), rep(1/6,6))
  x = roll(a, times = 100)
  expect_is(frequencies(x), "numeric")
})

test_that("Extraction method works as expected", {
  a = device(c(1,2,3,4,5,6), rep(1/6,6))
  set.seed(123)
  x = roll(a, times = 100)
  expect_equal(x[100], 5)
  expect_is(x[100], "numeric")
  expect_error(x[101], NA)
})

test_that("Replacement method works as expected", {
  a = device(c(1,2,3,4,5,6), rep(1/6,6))
  set.seed(123)
  x = roll(a, times = 100)
  x[100] = 1
  expect_equal(x[100], 1)
})

test_that("Addition method works as expected", {
  a = device(c('z', 'c', 'g', 'f'), rep(1/4, 4))
  set.seed(123)
  x = roll(a, times = 70)
  set.seed(123)
  x = x + 100
  set.seed(123)
  y = roll(a, times = 70)
  set.seed(123)
  y = y + 100
  expect_error(x-50)
  expect_equal(x, y)
})
