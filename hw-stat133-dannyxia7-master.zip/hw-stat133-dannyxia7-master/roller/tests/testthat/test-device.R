library(roller)

context("Test for device object")

test_that("device function works as expected", {
  sides_n = c(1, 2, 3, 4, 5, 6)
  prob_f = rep(1/6, 6)
  y = device(sides_n, prob_f)
  expect_length(device(sides_n, prob_f), 2)
  expect_equal(device(sides_n, prob_f), y)
  expect_type(device(sides_n, prob_f), "list")
})

test_that("check_sides works as expected", {
  sides_e = c('a', 'a', 'b')
  sides_1 = c(1)
  sides_n = c('a', 'b', 'c', 'd', 'e')

  expect_error(check_sides(sides_e))
  expect_error(check_sides(sides_1))
  expect_equal(check_sides(sides_n), TRUE)
  expect_type(check_sides(sides_n), 'logical')
})

test_that("check_prob works as expected", {
  prob_w = c(1.5, 2, 4)
  prob_a = c('a', 'b')
  prob_1 = c(1)
  prob_t = c(.5, .499999)
  prob_n = c(.2, .4, .3, .1)

  expect_error(check_prob(prob_w))
  expect_error(check_prob(prob_a))
  expect_error(check_prob(prob_1))
  expect_error(check_prob(prob_t))
  expect_equal(check_prob(prob_n), TRUE)
  expect_type(check_prob(prob_n), 'logical')
})

test_that("print.device works as expected", {
  x = device(sides = c(1,2,3), prob = rep(1/3, 3))

  expect_length(x, 2)
  expect_type(x, 'list')
  expect_is(x, "device")
})

test_that("is.device works as expected", {
  x = device(sides = c(1,2,3,4), prob = rep(1/4, 4))
  y = 5

  expect_true(is.device(x))
  expect_false(is.device(y))
})
