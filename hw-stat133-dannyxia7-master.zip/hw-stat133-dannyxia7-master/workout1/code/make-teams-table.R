#title: Team Tables Data Preprocessing
#description: Preparing data to create csv file nba2018-teams.csv and summaries of efficiency and teams
#input: nba2018.csv, dplyr, readr
#output: efficiency-summary.txt, teams-summary.txt, nba2018-teams.csv

library(dplyr)
library(readr)
dat = read_csv("../data/nba2018.csv", col_types = 
                 cols(experience = col_character(),
                      salary = col_double(),
                      position = col_factor(levels = c('C', 'PF', 'PG', 'SF', 'SG')))
)
dat$experience[dat$experience == "R"] = 0
dat = type_convert(dat, col_types = cols(experience = col_integer()))
dat$salary = dat$salary/1000000
levels(dat$position) = c("center", "power_fwd", "point_guard", "small_fwd", "shoot_guard")
dat = 
  dat %>% 
  mutate(missed_fg = field_goals_atts - field_goals,
         missed_ft = points1_atts - points1,
         rebounds = off_rebounds + def_rebounds,
         efficiency = (points + rebounds + assists + steals + blocks - missed_fg - missed_ft - turnovers)/games
  )
sink("../output/efficiency-summary.txt")
summary(dat$efficiency)
sink()

teams = 
  dat %>%
  group_by(team) %>%
  summarise(experience = sum(experience), salary = sum(salary), points3 = sum(points3), points2 = sum(points2), points1 = sum(points1), points = sum(points), off_rebounds = sum(off_rebounds), def_rebounds = sum(def_rebounds), assists = sum(assists), steals = sum(steals), blocks = sum(blocks), turnovers = sum(turnovers), fouls = sum(fouls), efficiency = sum(efficiency))
sink("../output/teams-summary.txt")
summary(teams)
sink()
write_csv(teams, "../data/nba2018-teams.csv")