---
title: "nba2018-dictionary"
author: "Danny Xia"
date: "9/26/2018"
output: github_document
---

#Workout 1 Data Dictionary
This data is compiled from the National Basketball Association, the NBA, and compiles traditional statistics like points, rebounds, and assists of all the players in the league of all the teams. 

###Main source:
<www.basketballreference.com>

Sample link:
[Warriors' Data](https://www.basketball-reference.com/teams/GSW/2018.html)

###General Info:
*477 rows
*38 columns
*Missing values are codified as NA

###Variables
####Format of data dictionary variables is: names, descriptions, units, possible missing values
*player: first and last names of player, character
*number: number on jersey, integer
*team: 3-letter team abbreviation, character
*position: player's position, character
*height: height in feet-inches, integer
*weight: weight in pounds, integer
*birth_date: date of birth ("Month day, year"), character
*country: 2-letter country abbreviation, character
*experience: years of experience in NBA (a value of R means rookie), character
*college: attended college in USA, character, NAs of players that didn't go to college and international players
*salary: player salary in dollars, double
*rank: Rank of player in his team, integer
*age: Age of player at the start of February 1st of that season, integer
*games: Games played during regular season, integer
*games_started: Games started, integer
*minutes: Minutes played during regular season, integer
*field_goals: Field goals made, integer
*field_goals_atts: Field goal attempts, integer
*field_goals_perc: Field goal percentage, double, NAs where players did not take a shot in the season
*points3: 3-Points field goals, integer
*points3_atts: 3-Point field goal attempts, integer
*points3_perc: 3-Point field goal percentage, double, NAs when player did not take a 3-point shot in the season
*points2: 2-Point field goals, integer
*points2_atts: 2-Point field goal attempts, integer
*points2_perc: 2-Point field goal percentage, double, NAs when player did not take a two point field goal in the season
*effective_field_goal_perc: Effective field goal percentage, double, NAs when player did not take a shot in the season
*points1: Free throws made, integer
*points1_atts: Free throw attempts, integer
*points1_perc: Free throw percentage, double, NAs when player did not take a free throw in the season
*off_rebounds: Offensive rebounds, integer
*def_rebounds: Defensive rebounds, integer
*assists: Assists, integer
*steals: Steals, integer
*blocks: Blocks, integer
*turnovers: Turnovers, integer
*fouls: Fouls, integer
*points: Total points, integer

