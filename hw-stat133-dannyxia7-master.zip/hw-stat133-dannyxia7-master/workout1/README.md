This assignment is called workout1, and it's about Data Wrangling and Visualization.
We are using dplyr and ggplot2 packages.
Using player statistics like efficiency, we will try to rank NBA teams. Team statistics cannot be used.
The data is contained in a  csv file, nba2018.csv.

