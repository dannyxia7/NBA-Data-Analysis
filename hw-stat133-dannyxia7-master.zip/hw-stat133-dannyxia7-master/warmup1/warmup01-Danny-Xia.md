Warm-Up-01
================
Danny Xia
8/27/2018

Olly
====

> "For the Watch"

![](https://vignette.wikia.nocookie.net/gameofthrones/images/5/51/602_Olly_Promo_Crop.png/revision/latest?cb=20160708062640)

``` r
library(knitr)
df = data.frame(labels = c("Titles", "Status", "Death", "Origin", "Allegiance", "Culture"), values = c("Steward", "Deceased", "303 AC at Castle Black", "the Gift", "The Night's Watch", "Northmen"))
kable(df)
```

| labels     | values                 |
|:-----------|:-----------------------|
| Titles     | Steward                |
| Status     | Deceased               |
| Death      | 303 AC at Castle Black |
| Origin     | the Gift               |
| Allegiance | The Night's Watch      |
| Culture    | Northmen               |

Foccacia Sandwiches for a Crowd

-   4 cups(520 grams) all-purpose flour
-   2 teaspoon kosher salt
-   1 teaspoon instant yeast
-   2 cups lukewarm water, made by mixing 1/2 cup boiling water with 1 1/2 cups cold water
-   4 tablespoons olive oil
-   Flaky sea salt

Whisk flour salt and yeast in a bowl, then add water. *Mix* until the water is absorbed and you have dough, then cover it with a towel or plastic wrap and either set it aside in a warm spot for an hour to an hour and a half, leave it overnight in the fridge for 8 to 12 hours, or leave it overnight at room temperature in a bowl of lukewarm water. When ready to make the focaccia, pour oil on it and place it on a sheet pan, then heat the oven to 425 degrees fahrenheit, let the dough rest for **20 minutes**, then sprinkle it with sea salt and bake for 20 to 25 minutes.

![Foccacia](https://farm1.staticflickr.com/853/42146964650_752f810755_z.jpg)

For alternative sandwich fillings, you can use *avocado and crispy kale* or *hummus with cucumber and pickled carrots*.

Quadratic Equation
A quadratic equation is any equation having this form, where x represents an *unknown*, and a, b, and c represent *known* numbers such that a is **not** equal to 0.

Derivation:
